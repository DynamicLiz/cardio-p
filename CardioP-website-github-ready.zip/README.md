# CardioP Website

GitHub-ready, responsive three-page static website for CardioP.

## Preview
Open `index.html` in a browser, or run:
`python -m http.server 8000`
Then visit `http://localhost:8000`.

## GitHub Pages
Create a repository, upload these files to the repository root, then go to:
Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

## Included
- Homepage, About and Contact pages
- Supplied CardioP logo
- Responsive mobile navigation
- Scroll animations and hover interactions
- Interactive product tabs
- Interactive CardioP AI demo
- Contact form validation and demo success state
- Health/safety disclaimers
- No fabricated company statistics or partnerships

The contact form is frontend-only until a backend/form service is connected.
The typeface uses a clean web fallback. Add a licensed Agrandir webfont if available.
