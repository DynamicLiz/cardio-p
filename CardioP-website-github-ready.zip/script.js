
const menuBtn=document.querySelector('.menu-btn');
const nav=document.querySelector('.nav-links');
if(menuBtn) menuBtn.addEventListener('click',()=>nav.classList.toggle('open'));

document.querySelectorAll('.nav-links a').forEach(a=>{
  a.addEventListener('click',()=>nav?.classList.remove('open'));
});

const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')});
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

document.querySelectorAll('[data-tabs]').forEach(group=>{
  const buttons=group.querySelectorAll('.tab');
  const copies=group.parentElement.querySelectorAll('.tab-copy');
  buttons.forEach(btn=>{
    btn.addEventListener('click',()=>{
      buttons.forEach(b=>b.classList.remove('active'));
      copies.forEach(c=>c.classList.remove('active'));
      btn.classList.add('active');
      group.parentElement.querySelector('#'+btn.dataset.target)?.classList.add('active');
    });
  });
});

const questions=[
  "What does high blood pressure mean?",
  "Why is medication adherence important?",
  "What can increase my cardiovascular risk?",
  "How can I improve my heart health?"
];
const replies=[
  "High blood pressure means the force of blood against your artery walls is consistently higher than recommended. A healthcare professional can help you understand your readings and what they mean for you.",
  "Taking prescribed medicines consistently can help your treatment work as intended. If you have concerns about a medicine, speak with your healthcare professional rather than changing your treatment on your own.",
  "Cardiovascular risk can be influenced by factors such as blood pressure, smoking, diabetes, cholesterol, physical activity, diet, age and family history. Risk is personal, so professional assessment matters.",
  "Start with sustainable habits: know your blood pressure, stay active in ways that suit you, eat a varied balanced diet, avoid smoking, and keep up with recommended healthcare visits."
];
document.querySelectorAll('.chip').forEach((chip,i)=>{
  chip.addEventListener('click',()=>{
    const body=document.querySelector('.chat-body');
    if(!body)return;
    const user=document.createElement('div'); user.className='bubble user'; user.textContent=questions[i]; body.appendChild(user);
    const typing=document.createElement('div'); typing.className='bubble bot'; typing.textContent='CardioP AI is typing…'; body.appendChild(typing);
    body.scrollTop=body.scrollHeight;
    setTimeout(()=>{typing.textContent=replies[i];body.scrollTop=body.scrollHeight},700);
  });
});

const form=document.querySelector('#contactForm');
if(form){
 form.addEventListener('submit',e=>{
  e.preventDefault();
  const msg=document.querySelector('.form-msg');
  if(!form.checkValidity()){msg.textContent='Please complete the required fields.';msg.className='form-msg show error';return;}
  msg.textContent='Thanks. Your message has been captured in this demo. Connect a backend or form service to receive submissions.';
  msg.className='form-msg show success'; form.reset();
 });
}
