// ============================================================
// CardioP — shared interactions
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  /* ---------- ECG scroll progress ---------- */
  const bar = document.querySelector('.ecg-progress__bar');
  const updateProgress = () => {
    if(!bar) return;
    const h = document.documentElement;
    const scrolled = h.scrollTop;
    const max = h.scrollHeight - h.clientHeight;
    bar.style.width = max > 0 ? `${(scrolled / max) * 100}%` : '0%';
  };
  document.addEventListener('scroll', updateProgress, { passive: true });
  updateProgress();

  /* ---------- mobile nav ---------- */
  const toggle = document.querySelector('.nav__toggle');
  const mobileMenu = document.querySelector('.nav__mobile');
  if(toggle && mobileMenu){
    toggle.addEventListener('click', () => {
      const open = toggle.classList.toggle('is-open');
      mobileMenu.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
    });
    mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      toggle.classList.remove('is-open');
      mobileMenu.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    }));
  }

  /* ---------- reveal on scroll ---------- */
  const revealEls = document.querySelectorAll('.reveal, .step');
  if('IntersectionObserver' in window && revealEls.length){
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if(entry.isIntersecting){
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.18 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('is-visible'));
  }

  /* ---------- product tabs ---------- */
  const tabs = document.querySelectorAll('.tab');
  const panels = document.querySelectorAll('.tab-panel');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('is-active'));
      panels.forEach(p => p.classList.remove('is-active'));
      tab.classList.add('is-active');
      const panel = document.getElementById(tab.dataset.tab);
      if(panel) panel.classList.add('is-active');
    });
  });

  /* ---------- chatbot demo ---------- */
  const chatBody = document.querySelector('.chat-window__body');
  const prompts = document.querySelectorAll('.chatbot__prompt');

  const answers = {
    'What does high blood pressure mean?':
      "High blood pressure means the force of blood against your artery walls stays higher than typical over time. It often has no symptoms, which is why regular checks matter.",
    'Why is medication adherence important?':
      "Taking prescribed medication consistently helps keep your risk factors under control. Skipping doses can let those factors rise again, even if you feel fine.",
    'What can increase my cardiovascular risk?':
      "Factors like elevated blood pressure, high cholesterol, smoking, inactivity, and family history can all raise cardiovascular risk. Several of these can be managed over time.",
    'How can I improve my heart health?':
      "Small, steady habits help most: regular movement, balanced meals, quality sleep, stress management, and keeping up with checkups and prescribed care."
  };

  function addMessage(text, cls){
    if(!chatBody) return;
    const div = document.createElement('div');
    div.className = `msg ${cls}`;
    div.textContent = text;
    chatBody.appendChild(div);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  function askQuestion(question){
    if(!chatBody) return;
    prompts.forEach(p => p.classList.remove('is-active'));
    const activePrompt = Array.from(prompts).find(p => p.textContent.trim() === question);
    if(activePrompt) activePrompt.classList.add('is-active');

    chatBody.innerHTML = '';
    addMessage(question, 'msg--user');

    const typing = document.createElement('div');
    typing.className = 'typing';
    typing.innerHTML = '<span></span><span></span><span></span>';
    chatBody.appendChild(typing);
    chatBody.scrollTop = chatBody.scrollHeight;

    setTimeout(() => {
      typing.remove();
      addMessage(answers[question] || "That's a great cardiovascular health question — CardioP AI is designed to help you explore it in plain language.", 'msg--bot');
    }, 1100);
  }

  prompts.forEach(btn => {
    btn.addEventListener('click', () => askQuestion(btn.textContent.trim()));
  });

  /* ---------- contact form ---------- */
  const form = document.querySelector('.form');
  if(form){
    const status = form.querySelector('.form__status');

    const validators = {
      name: v => v.trim().length >= 2,
      email: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()),
      subject: v => v.trim().length > 0,
      message: v => v.trim().length >= 10
    };

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let valid = true;

      Object.keys(validators).forEach(name => {
        const field = form.querySelector(`[name="${name}"]`);
        if(!field) return;
        const wrapper = field.closest('.field');
        const ok = validators[name](field.value);
        wrapper.classList.toggle('has-error', !ok);
        if(!ok) valid = false;
      });

      if(!status) return;
      status.classList.remove('is-success', 'is-error');

      if(valid){
        status.textContent = "Message received. Thank you for reaching out — the CardioP team will follow up soon.";
        status.classList.add('is-success');
        form.reset();
        form.querySelectorAll('.field').forEach(f => f.classList.remove('has-error'));
      } else {
        status.textContent = "Please check the highlighted fields before sending your message.";
        status.classList.add('is-error');
      }
      status.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
  }

});
