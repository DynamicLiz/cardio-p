# CardioP Website

Predict. Prevent. Protect. — a static, three-page marketing site for CardioP, a Nigerian digital cardiovascular health platform.

## Structure

- `index.html` — Homepage (hero, problem, product tabs, AI chatbot demo, accessibility, community outreach, how it works, values, CTA)
- `about.html` — Vision, mission, approach, impact
- `contact.html` — Contact form with validation
- `styles.css` — Shared design system and component styles
- `script.js` — Shared interactions (nav, scroll reveal, tabs, chatbot demo, form validation)

No build step or dependencies — plain HTML/CSS/JS.

## Preview locally

Open `index.html` directly in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Push to GitHub

From inside this folder:

```bash
git init
git add .
git commit -m "Initial CardioP website"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

To publish with GitHub Pages: repo Settings → Pages → deploy from the `main` branch, root folder.
